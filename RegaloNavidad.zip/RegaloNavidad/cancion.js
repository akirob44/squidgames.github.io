sound = new Audio();
sound.src = "musica/navidad.mp3";