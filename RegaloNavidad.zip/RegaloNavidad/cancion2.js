sound = new Audio();
sound.src = "musica/navidad2.mp3";